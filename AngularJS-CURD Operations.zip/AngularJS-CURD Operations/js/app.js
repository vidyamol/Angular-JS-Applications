var app = angular.module("myModule", [])
							   .controller("myController", function($scope){
			
								$scope.newMember = {};
								$scope.clickedMembers = [];
								
								$scope.members = [
									{name: "Vidya S", email: "vidyasrinivasula@gmail.com", gender: "Female"},
									{name: "Ashok S", email: "ashoksrni@yahoo.com", gender: "Male"},
									{name: "Varsha S", email: "varshas@gmail.com", gender: "Female"}
								];
								
								$scope.saveMember = function(){
									$scope.members.push($scope.newMember);
									$scope.newMember = {};
								};		
								
								$scope.selectMember =  function(member){
									$scope.selectedMember = member;
								};
								
								$scope.updateMember = function(){
									
								};
								
								$scope.deleteMember = function(){
									$scope.members.splice($scope.members.indexOf($scope.selectMember), 1);
								};
						});